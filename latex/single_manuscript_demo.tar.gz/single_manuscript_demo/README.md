Demo for Single-Manuscript Vimscript
======================================

See comments in `single_manuscript.vim` for details.

## Instructions (shell prompt)

1. Untar and enter directory if needed.
2. Back up original `main.tex`.
3. Run script (make executable if needed).
4. Copy output onto `main.tex`.
5. Compile document.

## Example

```bash
tar xzvf single_manuscript_demo.tar.gz
cd single_manuscript_demo
cp main.tex main.tex.bak
chmod 755 single_manuscript.vim
./single_manuscript.vim
cp manuscript.tex main.tex
make
```

